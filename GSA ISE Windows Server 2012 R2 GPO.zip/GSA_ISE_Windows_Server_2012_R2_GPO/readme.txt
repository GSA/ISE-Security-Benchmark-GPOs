4:11 PM 8/4/2017

GSA ISE Windows Server 2012 R2 GPO

ADMs used:

<MSS-legacy> from...
https://blogs.technet.microsoft.com/secguide/2016/10/02/the-mss-settings/

<CIS_Microsoft_Windows_Server_2012_R2_Remediation_Kit_v2.1.0.zip> which includes <Disable-IPv6-Components-KB929852.adm> from...
https://workbench.cisecurity.org/files/1156

<Windows8.1-Update-ADMX> which includes <ShapeCollector.admx/adml> and <Search.admx/adml> from...
https://www.microsoft.com/en-us/download/confirmation.aspx?id=43413

<Windows10-ADMX> which includes <avsvalidationgp.admx/adml> from... https://www.microsoft.com/en-us/download/confirmation.aspx?id=48257

=================================================
Settings not configured:
2.2.17 - User List
2.2.21 - User List
18.9.61.3 - doesn't map over (Store)
=================================================

GSA ISE Windows Server 2012 R2 - LOCAL INSTALL

To apply this GSA Security Template locally only (e.g. for an endpoint that is not connected to the domain), follow these steps:

1) Extract the contents of the "GSA_ISE_Windows_Server_2012_R2_Local_Install" zip file to the endpoint; Consider extracting the contents directly to the C:\ drive to allow for easier syntax input on the command-line in the steps to follow.
2) Before proceeding, ensure that there is ANOTHER local administrator account other than the default administrator account, which is also a member of the Remote Desktop Users group. This other local administrator account may be required to access the endpoint following the application of this GSA Security Template.
3) Open a Command Prompt window (Run as Administrator)
4) Assuming the file contents in Step 1 were extracted directly to the C:\ drive, enter the following command (otherwise, modify the file path as necessary):
	C:\LGPO.exe /s C:\GptTmpl.inf
5) Wait for confirmation in the Command Prompt window that the security template has been applied and then REBOOT the endpoint.

***Please Note: The Local Accounts SID (S-1-5-113) was removed from the "SeDenyRemoteInteractiveLogonRight" privilege rights parameter to allow for subsequent Remote Desktop logins following the application of this GSA Security Template. This privilege rights restriction for Local Accounts, however, will be in effect when using the domain GPO.

{EOD}