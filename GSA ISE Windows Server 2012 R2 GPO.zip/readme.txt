GSA ISE Windows Server 2012 R2 GPO


ADMs used:

<MSS-legacy> from...
https://blogs.technet.microsoft.com/secguide/2016/10/02/the-mss-settings/

<CIS_Microsoft_Windows_Server_2012_R2_Remediation_Kit_v2.1.0.zip> which includes <Disable-IPv6-Components-KB929852.adm> from...
https://workbench.cisecurity.org/files/1156

<Windows8.1-Update-ADMX> which includes <ShapeCollector.admx/adml> and <Search.admx/adml> from...
https://www.microsoft.com/en-us/download/confirmation.aspx?id=43413

<Windows10-ADMX> which includes <avsvalidationgp.admx/adml> from... https://www.microsoft.com/en-us/download/confirmation.aspx?id=48257

=================================================

Settings not configured:
2.2.17 - User List
2.2.21 - User List
18.9.61.3 - doesn't map over (Store)


RLR - 5:49 PM 5/19/2017 

{EOD}